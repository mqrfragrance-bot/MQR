async function getData() {
    const url = document.getElementById("videoUrl").value;
    const API_KEY = "AIzaSyA0FnmIzjxyfa506ru3f5lzc-IVrt-9QM0";

    const videoId = url.split("v=")[1]?.split("&")[0];

    if (!videoId) {
        alert("Invalid YouTube URL");
        return;
    }

    const API_URL = `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${videoId}&key=${API_KEY}`;

    const res = await fetch(API_URL);
    const data = await res.json();

    const info = data.items[0].snippet;

    document.getElementById("title").value = info.title;
    document.getElementById("description").value = info.description;
    document.getElementById("tags").value = info.tags ? info.tags.join(", ") : "No Tags Found";
    document.getElementById("hashtags").value = info.tags ? 
        info.tags.map(t => "#" + t.replace(/\s+/g, "")).join(" ") : 
        "No Hashtags Found";
}