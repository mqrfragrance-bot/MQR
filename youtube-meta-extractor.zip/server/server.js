const express = require('express')
const fetch = require('node-fetch') || require('undici').fetch
const cors = require('cors')
const app = express()
app.use(cors())
app.use(express.json())

const PORT = process.env.PORT || 3001
const API_KEY = process.env.YT_API_KEY

if (!API_KEY) {
  console.warn('Warning: YT_API_KEY is not set in environment. Set it in Vercel env variables or .env for local testing.')
}

app.get('/api/getVideo', async (req, res) => {
  const videoId = req.query.videoId
  if (!videoId) return res.status(400).json({ error: 'videoId required' })
  try {
    const resp = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${videoId}&key=${API_KEY}`)
    const data = await resp.json()
    res.json(data)
  } catch (err) {
    res.status(500).json({ error: String(err) })
  }
})

app.listen(PORT, () => console.log('Server running on port', PORT))
