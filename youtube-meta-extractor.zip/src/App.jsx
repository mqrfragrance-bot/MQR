import React, { useState } from 'react'

export default function App() {
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState(null)
  const [condense, setCondense] = useState(true)

  function extractVideoId(input) {
    try {
      input = (input||'').trim()
      if (/^[a-zA-Z0-9_-]{11}$/.test(input)) return input
      let m = input.match(/youtu\\.be\\/([-_A-Za-z0-9]{11})/) || input.match(/[?&]v=([-_A-Za-z0-9]{11})/)
      if (m) return m[1]
      return null
    } catch (e) { return null }
  }

  async function fetchMetadata() {
    setError(''); setResult(null)
    const id = extractVideoId(url)
    if (!id) { setError('Invalid YouTube URL or ID'); return }
    setLoading(true)
    try {
      const resp = await fetch(`/api/getVideo?videoId=${id}`)
      if (!resp.ok) throw new Error('Server error: ' + resp.status)
      const data = await resp.json()
      const item = (data.items && data.items[0]) || data
      const snippet = item.snippet || {}
      const tags = snippet.tags || []
      const description = snippet.description || ''
      const hashtags = Array.from(new Set((description.match(/#[\p{L}0-9_\-]+/gu) || []).map(h => h.trim())))
      setResult({ title: snippet.title||'', tags, hashtags, description })
    } catch (e) {
      setError(String(e.message||e))
    } finally { setLoading(false) }
  }

  function condensedText(text) {
    if (!condense) return text
    return (text||'').replace(/\r/g,'').split('\n').map(l=>l.trim()).filter(Boolean).join(' ')
  }

  function copyJSON() {
    if (!result) return
    navigator.clipboard.writeText(JSON.stringify(result, null, 2))
  }

  return (
    <div className="min-h-screen p-6 flex items-start justify-center">
      <div className="w-full max-w-3xl bg-white rounded-2xl shadow p-6">
        <h1 className="text-2xl font-semibold mb-2">YouTube Meta Extractor</h1>
        <p className="text-sm text-gray-600 mb-4">Paste a YouTube URL or video ID to extract tags, hashtags and description.</p>

        <div className="space-y-2">
          <input value={url} onChange={e=>setUrl(e.target.value)} placeholder="Paste YouTube URL or ID" className="w-full p-3 border rounded" />
          <div className="flex gap-2">
            <button onClick={fetchMetadata} className="px-4 py-2 bg-blue-600 text-white rounded">Fetch</button>
            <button onClick={()=>{ setUrl(''); setResult(null); setError('') }} className="px-3 py-2 border rounded">Reset</button>
            <label className="ml-auto flex items-center gap-2 text-sm">
              <input type="checkbox" checked={condense} onChange={e=>setCondense(e.target.checked)} /> Condense description
            </label>
          </div>
        </div>

        <div className="mt-6">
          {loading && <div className="text-sm text-gray-500">Loading…</div>}
          {error && <div className="text-sm text-red-600">{error}</div>}

          {result && (
            <div className="mt-4 space-y-4">
              <div>
                <h2 className="font-semibold">Title</h2>
                <div className="p-3 bg-gray-100 rounded">{result.title}</div>
              </div>

              <div>
                <h2 className="font-semibold">YouTube Tags (from API)</h2>
                <div className="p-3 bg-gray-50 rounded flex flex-wrap gap-2">
                  {result.tags.length ? result.tags.map(t=>(
                    <span key={t} className="px-2 py-1 bg-white border rounded text-sm">{t}</span>
                  )) : <span className="text-sm text-gray-500">No tags found</span>}
                </div>
              </div>

              <div>
                <h2 className="font-semibold">Hashtags (parsed from description)</h2>
                <div className="p-3 bg-gray-50 rounded flex flex-wrap gap-2">
                  {result.hashtags.length ? result.hashtags.map(h=>(
                    <span key={h} className="px-2 py-1 bg-white border rounded text-sm">{h}</span>
                  )) : <span className="text-sm text-gray-500">No hashtags found</span>}
                </div>
              </div>

              <div>
                <h2 className="font-semibold">Description</h2>
                <div className="p-3 bg-gray-100 rounded max-h-56 overflow-auto whitespace-pre-wrap">
                  {condensedText(result.description)}
                </div>
                <div className="mt-2 flex gap-2">
                  <button onClick={()=>navigator.clipboard.writeText(condensedText(result.description))} className="px-3 py-1 border rounded text-sm">Copy description</button>
                  <button onClick={copyJSON} className="px-3 py-1 border rounded text-sm">Copy JSON</button>
                  <a className="ml-auto text-xs text-gray-500" href="#" target="_blank" rel="noreferrer">Open on YouTube</a>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 text-xs text-gray-500">
          Note: For reliability, run a small server endpoint (example included) and set YT_API_KEY in environment variables.
        </div>
      </div>
    </div>
  )
}
